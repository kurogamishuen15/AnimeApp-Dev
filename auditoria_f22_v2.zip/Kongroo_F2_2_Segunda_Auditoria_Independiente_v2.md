# KONGROO — Segunda auditoría independiente F2.2 (v2)

**Fecha:** 2026-11-09 (revisión del paquete remitido)  
**Objeto:** `Kongroo-F2.2-Auditoria-v2.zip`  
**Dictamen:** **F2.2 NO ACEPTADA. No comenzar F2.3.**  
**Método:** revisión estática completa de 25 entradas del ZIP; comparación con el informe independiente anterior (A1–A12); lectura de tests, documentación, lockfile y referencias upstream de Flutter/media_kit. No se ejecutó Flutter/libmpv en el Fedora del usuario desde el entorno revisor.

## 1. Alcance y evidencia

- Paquete: **25 entradas** (24 archivos objeto listados en el inventario, más el inventario).
- **Integridad:** verificados los 24 hashes SHA-256 y tamaños declarados: 24/24 correctos.
- 4 suites incluidas: 4 pruebas de lease + 5 del coordinador + 1 snapshot + 1 integración nativa = **11 tests** de reproductor.
- CI, Flutter analyze, 73 tests totales y Linux build: **resultados históricos reportados por Codex**, no reejecutados independientemente; el inventario admite que **no incluye logs crudos**.
- No viene el MP4 de fixture en el ZIP v2, ni el directorio `.ai-local`, ni `app/linux/`; no se pudieron repetir pruebas audiovisuales o revisar el bundle nativo con este paquete.
- Se consultaron la documentación actual de Flutter y media_kit y las versiones `media_kit 1.2.6` / `media_kit_video 2.0.1` indicadas en el lockfile. El código fuente local del paquete instalado por Codex, y las afirmaciones sobre el orden interno de su dispose, **no están incorporados en el ZIP** y no se verificaron byte por byte en esta revisión.

## 2. Comparación con la primera auditoría de 12 hallazgos

| Hallazgo anterior | Estado en v2 | Evidencia |
|---|---|---|
| **A1 — Doble Player durante dispose** | **Mitigado** | `active_player_lease.dart:12-18,37-61`; ensayo de release pendiente en `active_player_lease_test.dart:7-34`. Queda sin simular fallo parcial real de libmpv. |
| **A2 — Error desaparece tras evento** | **Corregido en snapshot** | `playback_spike_contract.dart:31-46`, `media_kit_spike_engine.dart:125-140`; test `playback_spike_snapshot_test.dart:4-16`. Faltan tests de stream nativo. |
| **A3 — Slider lanza seek por cada movimiento** | **ABIERTO** | `spike_player_page.dart:79-89`. |
| **A4 — Cierre de ventana no esperado/verificado** | **ABIERTO** | `main_player_spike.dart:30-35`, uso de `unawaited`. |
| **A5 — Fixture invisible en clon limpio** | **ABIERTO** | `media_kit_spike_integration_test.dart:10-12`, `.ai-local` ignorado; no hay generador ni recurso versionado en paquete. |
| **A6 — Stop sin verificar reutilización** | **ABIERTO** | `media_kit_spike_integration_test.dart:79-85` solo stop → dispose. |
| **A7 — Tests negativos/VideoController insuficientes** | **PARCIAL** | Añadidas pruebas de lease y dispose de fake; siguen sin test archivo inválido, fallos nativos, VideoController real, cierre de ventana y recuperación. |
| **A8 — Esquema `file:` solo validado en coordinador** | **ABIERTO** | `spike_player_coordinator.dart:43-45` valida; `media_kit_spike_engine.dart:134-140` no valida. |
| **A9 — Operación colgada bloquea dispose** | **ABIERTO** | `spike_player_coordinator.dart:73-80,121-131`: dispose va detrás de `_tail`. |
| **A10 — Stream público queda abierto si falla dispose** | **Corregido** | `spike_player_coordinator.dart:90-115`, test `spike_player_coordinator_test.dart:55-71`. |
| **A11 — README y imports contradictorios** | **ABIERTO** | `app/player/README.md` dice que solo el puente importa `media_kit_video`, pero `spike_player_page.dart:4` también importa ese paquete. `main_player_spike.dart:5` importa media_kit. |
| **A12 — Ruta del fixture depende del cwd** | **ABIERTO** | `main_player_spike.dart:12-17` usa `Directory.current.parent`. |

**Balance:** 3 hallazgos corregidos/mitigados, 1 parcialmente corregido, 8 abiertos. Los cuatro F22-001…004 del auditor **local** son un conjunto distinto a los 12 A1…A12 del informe independiente compartido por el usuario. La frase de Codex «los cuatro hallazgos originales están corregidos» es válida solo en el contexto de su auditoría local, no para los doce problemas del informe independiente externo.

## 3. Bloqueantes de prioridad alta (P1)

### F22V2-01 — P1 — Seek continuo y cola sin conflación

**Código:** `app/lib/app/player/spike_player_page.dart:79-89`; `app/lib/application/player/spike_player_coordinator.dart:121-131`.

**Evidencia demostrada:** `onChanged` llama `_command(coordinator.seek(...))` cada vez. `_serialize` registra una operación por llamada y no descarta intermedias. Un arrastre con muchos eventos encola muchos seeks. No hay test UI del gesto.

**Corrección:** mantener posición temporal durante el arrastre, y hacer **un solo seek en `onChangeEnd`**; prevenir que cambios de posición del motor sobrescriban el valor temporal; gestionar errores de ese comando. Test de widget/fake contando llamadas por gesto.

### F22V2-02 — P1 — Cierre asíncrono de ventana sin garantía ni manejo de errores

**Código:** `app/lib/main_player_spike.dart:30-35`.

**Evidencia:** `unawaited(module.close())` no observa fallos ni espera la terminación. La documentación Flutter advierte expresamente que el árbol de widgets puede no desmontarse al terminar el proceso. No hay hook de cierre gráfico probado ni prueba de cierre normal.

**Corrección:** diseñar un flujo de cierre ordenado controlable donde la plataforma lo permita; tratar y registrar error de close; demostrar cierre con el entorno Fedora (la terminación forzosa no es recuperable ni garantiza callbacks). Mantener el flujo simple y aislado de F2.2.

**Fuente:** https://api.flutter.dev/flutter/widgets/runApp.html

### F22V2-03 — P1 — `dispose` depende de una operación anterior que puede no finalizar

**Código:** `app/lib/application/player/spike_player_coordinator.dart:73-80,121-131`.

**Evidencia estructural:** `_disposeResources()` se encola tras `_tail`. Si un `open/seek/play` en el motor devuelve un Future pendiente indefinidamente, `_tail` nunca habilita la liberación. No existe timeout/estrategia de cancelación comprobada.

**Corrección:** establecer política acotada de salida y recuperación compatible con media_kit; comprobar que no se intenta disponer un recurso mientras el método nativo lo usa sin garantía del upstream. Prueba determinista con fake cuyo `open` permanece pendiente y posterior solicitud de `dispose`. Distinguir resolución del `Future` de la liberación real de recursos: timeout no equivale a cancelación.

### F22V2-04 — P1 — Falta evidencia del requisito de video visible en Fedora

**Código:** `app/lib/data/player/engine/media_kit_spike_engine.dart:90-96` y `app/lib/app/player/media_kit_video_surface.dart:5-12`.

**Evidencia:** no existe en v2 test de `VideoController` real ni `waitUntilFirstFrameRendered` ni una captura de la ventana que muestre fotogramas. El informe de Codex reconoce expresamente esa falta. La prueba de reproducción nativa no verifica la textura del compositor.

**Corrección:** ejecutar spike desde sesión gráfica real, comprobar primer frame, cambios de imagen y controles. La señal `waitUntilFirstFrameRendered` con timeout es evidencia complementaria, **no sustituye** verificación visual en la ventana.

**Fuente:** https://pub.dev/documentation/media_kit_video/latest/media_kit_video/VideoController-class.html

## 4. Hallazgos de prioridad media (P2)

### F22V2-05 — P2 — Fixture no reproducible desde clon limpio

**Código:** `app/test/player/media_kit_spike_integration_test.dart:10-12`.

**Corrección:** versionar pequeño fixture sintético permitido o crear script determinista de generación de fixture, con verificación SHA-256, codec, duración y requisitos de FFmpeg; documentar y usarlo en CI. La ruta ignorada `.ai-local` por sí sola no garantiza disponibilidad.

### F22V2-06 — P2 — No se verifica semántica de stop/reopen

**Código:** `media_kit_spike_integration_test.dart:80-85`.

**Corrección:** tras stop comprobar estado observable, reabrir clip en **el mismo Player**, reproducir y demostrar progreso. `Player.stop()` descarga medios sin liberar instancia según API oficial.

**Fuente:** https://pub.dev/documentation/media_kit/latest/media_kit/Player-class.html

### F22V2-07 — P2 — Faltan pruebas negativas de integración y recuperación

**Pruebas:** `app/test/player/*.dart`.

**Ausentes:** URI `file:` inexistente, archivo dañado, propagación de stream.error nativo, recovery tras fallo, rechazo remoto directo en el adaptador, surface de video real, command close durante open, fallo nativo de dispose simulado. Los tests de fake del coordinador **no prueban** el resultado de media_kit real. Priorizar pruebas deterministas sin introducir abstracciones enormes.

### F22V2-08 — P2 — Adaptador no hace cumplir restricción local del spike

**Código:** `media_kit_spike_engine.dart:134-140`.

**Corrección:** comprobar `source.scheme == 'file'` en límite del adaptador, además de validación de coordinador; prueba con `https:` sin crear conexión. Considerar validación de recurso legible y manejo de ausencia.

### F22V2-09 — P2 — Contradicción de acoplamiento y documentación

**Código:** `spike_player_page.dart:4`; `app/player/README.md` (párrafo después de tabla); `main_player_spike.dart:5`.

**Corrección:** o bien extraer tipo específico para la superficie en el puente `MediaKitVideoSurface` y hacer que la página acepte un `Widget` (sin importar media_kit_video), o documentar explícitamente y justificar la dependencia actual. Mantener media_kit fuera del coordinador.

### F22V2-10 — P2 — Entrypoint depende del directorio de lanzamiento

**Código:** `main_player_spike.dart:12-17`.

**Corrección:** ruta de fixture configurable, sin hardcodear ruta absoluta del propietario, con default de desarrollo documentado; probar inicio desde directorio distinto.

### F22V2-11 — P2 — El build release reportado no seleccionó el spike

**Informe:** `docs/ai-system/audits/F2.2-audit-reevaluation-2026-11-09.md`, sección 6.

**Evidencia:** se ejecutó `flutter build linux --release --no-pub`, sin `-t lib/main_player_spike.dart`; Flutter usa `lib/main.dart` como entrada predeterminada. Ese resultado es válido para la aplicación principal, no prueba por sí mismo la compilación de release del spike.

**Corrección:** añadir verificación `flutter build linux --release --no-pub -t lib/main_player_spike.dart` y ejecución real de la variante del spike. Mantener evidencia separada de la app normal.

**Fuente:** https://flutter.googlesource.com/mirrors/flutter.git/+/refs/heads/main/packages/flutter_tools/lib/src/runner/options/common_options.dart

### F22V2-12 — P2 — Fallo de apertura inicial puede perder diagnóstico original

**Código:** `app/lib/app/player/spike_player_module.dart:25-28`; `app/lib/main_player_spike.dart:9-20`.

**Evidencia estructural:** si `coordinator.open()` lanza y durante catch `coordinator.dispose()` también lanza, la excepción de limpieza reemplaza la de apertura. Además, como `runApp()` ocurre después del open, el fallo inicial no se muestra en pantalla.

**Corrección:** preservar error principal y error secundario de limpieza en diagnóstico; mostrar o registrar fallo de inicio de forma segura en spike. Test determinista de doble fallo.

## 5. Riesgos y límites adicionales

- El método `ActivePlayerLease` está bien protegido contra liberar antes de completar el callback. La política de cuarentena si falla nativamente es conservadora; **no se comprobó con un fallo inducido de Player.dispose real**. No afirmar que el mecanismo elimina todos los tipos de fugas nativas.
- La evidencia de la integración real y los 73 tests de CI es **un reporte de Codex, no logs incluidos**. El ZIP sí permite comprobar las aserciones escritas en fuente.
- El test headless verifica eventos de Player, no necesariamente un frame presentado ni audio audible.
- Medición de CPU/RSS, rendimiento hardware modesto y auditoría completa de empaquetado/licencias quedan sin medición; una revisión detallada **de distribución** puede reservarse para F5, siempre que el spike F2.2 documente sus dependencias y no distribuya binarios sin revisar.
- La ausencia del árbol `app/linux/` y bundle impide auditar el cargador, configuración GTK o librerías de ese artefacto dentro de este paquete.
- El documento `docs/player/F2.2-spike-report.md` **reconoce** que el slider no es robusto y que aún no hay evidencia visual; es valioso que no oculte estas limitaciones, pero reconocer un defecto no equivale a corregirlo.

## 6. Criterios de aceptación F2.2

1. Prueba determinista de un único seek por arrastre, sin cola de seeks obsoletos.
2. Política probada para cierre normal del spike, errores en limpieza y operación previa colgada (sin asumir cancelación nativa inexistente).
3. Fuente sintética reproducible en una instalación limpia, test nativo con open/play/pause/seek/stop/reopen y dispose.
4. Pruebas de errores y recuperación del adaptador, además de fakes.
5. Prueba y evidencia visual: pantalla Fedora real mostrando fotogramas que cambian. Audio documentado y probado cuando disponible, o limitación concreta.
6. Build explícito del **entrypoint spike**; reportar versiones y comandos.
7. READMEs/documentos coherentes con código, registros P0–P3 y pruebas; preservar aislamiento con catálogo/Drift.
8. Auditoría independiente posterior; el propietario, no Codex, decide cierre. No avanzar F2.3.

## 7. Fuentes oficiales verificadas (consulta 2026-11-09)

- media_kit / Player (dispose, stop, open, seek): https://pub.dev/documentation/media_kit/latest/media_kit/Player-class.html
- media_kit versión fijada en lockfile: https://pub.dev/packages/media_kit/versions/1.2.6
- media_kit_video / VideoController (primer frame): https://pub.dev/documentation/media_kit_video/latest/media_kit_video/VideoController-class.html
- Flutter runApp / cierre del árbol: https://api.flutter.dev/flutter/widgets/runApp.html
- Flutter opción `target` y predeterminado `lib/main.dart`: https://flutter.googlesource.com/mirrors/flutter.git/+/refs/heads/main/packages/flutter_tools/lib/src/runner/options/common_options.dart

**Recomendación:** enviar este informe a Codex como archivo dentro de la raíz autorizada del proyecto y solicitar correcciones exclusivas de F2.2. No modificar el sistema de agentes. No etiquetar prueba histórica como reejecutada; detenerse tras audit/reporte.
